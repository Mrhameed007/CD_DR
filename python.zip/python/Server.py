import pandas as pd
import socket
import os
import pickle
import logging
import logging.handlers as handlers
from concurrent.futures import ThreadPoolExecutor
import threading
import schedule
import time
from data_transmitter import DataTransmitter

# Set up logging
logger = logging.getLogger('Logging')
logger.setLevel(logging.INFO)
log_filename = r'D:\Users\Public\python\Logging\Sender_LOG.log'
formatter = logging.Formatter(
    "[%(asctime)-5s:%(levelname)-8s:%(filename)-20s:%(lineno)-5s - %(funcName)-30s](%(threadName)-25s %(message)s")
logHandler = handlers.TimedRotatingFileHandler(log_filename, when='midnight', interval=1, backupCount=0)
logHandler.setLevel(logging.INFO)
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)


class DataTransferRequest:
    def __init__(self, csv_raw_data):
        self.csv_input_data = csv_raw_data

    def list_of_directories_in_directory(self, folder_path):
        return [os.path.join(folder_path, name) for name in os.listdir(folder_path) if
                os.path.isdir(os.path.join(folder_path, name))]

    def target_pool_fun(self):
        with ThreadPoolExecutor(max_workers=100) as watcher_threadpool:
            logger.info("Assigned 100 threads ")
            src_directory = self.csv_input_data['source_dir']
            #target_ip = self.csv_input_data['target_ip']
            target_ip ="192.168.1.16"
            scan_subdir_val = self.csv_input_data['scan_subdir_val']

            directories_list = self.list_of_directories_in_directory(src_directory) if scan_subdir_val else []

            # Create the DataTransmitter instance and submit its run method to the ThreadPoolExecutor
            data_transmitter = DataTransmitter(src_directory, directories_list, scan_subdir_val, target_ip)
            watcher_threadpool.submit(data_transmitter.run)

            if scan_subdir_val:
                logger.info(f"Above raw data is from multi sub folders: {len(directories_list)}")
            else:
                logger.info("Above raw data is from a single folder")


def start_service():
    logger.info("Started the client ...........")
    csv_path = r"D:\Users\Public\python\data.csv"
    df = pd.read_csv(csv_path)
    logger.info("Retrieved the data from CSV file " + str(csv_path))

    threads = []  # Store references to threads
    for index, row in df.iterrows():
        raw_data = row.to_dict()
        dtr = DataTransferRequest(raw_data)
        thread = threading.Thread(target=dtr.target_pool_fun)
        logger.info(f"Started the thread for {raw_data}")
        threads.append(thread)
        thread.start()

    # Join all threads to ensure they finish before returning
    for thread in threads:
        thread.join()
    logger.info("All threads completed.")


# Schedule the service to run every 1 minute
schedule.every(1).minutes.do(start_service)

logger.info("Main thread continues running while threads are processing.")
while True:
    schedule.run_pending()
    time.sleep(1)
