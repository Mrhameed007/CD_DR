import socket
import os
import pickle
import logging
import time
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger('Logging')


class DataTransmitter:
    def __init__(self, src_directory, list_of_directories, scan_value, receiver_ip):
        self.transmit_port = 1374
        self.source_directory = src_directory
        self.sub_directories = list_of_directories
        self.value_to_scan = scan_value
        self.dest_ip = receiver_ip

    def run(self):
        """
        Main function to process files from source directory and optionally its subdirectories.
        """
        logger.info(
            f"Starting data transmission for {self.source_directory} with scan_subdir_val: {self.value_to_scan}")

        # Get the list of subdirectories if scan_subdir_val is True
        if self.value_to_scan:
            if not self.sub_directories:
                logger.info(f"No subdirectories found in {self.source_directory}. Sending files directly.")
                self.send_files_in_sub_folder(self.source_directory)
            else:
                for sub_dir in self.sub_directories:
                    logger.info(f"Processing subdirectory: {sub_dir}")
                    self.send_files_in_sub_folder(sub_dir)

                logger.info(f"Processing files in the main folder: {self.source_directory}")
                self.send_files_in_sub_folder(self.source_directory)

        else:
            list_of_files = self.list_of_files_in_directory(self.source_directory)
            logger.info(f"Single directory with files: {list_of_files}")
            with ThreadPoolExecutor(max_workers=100) as thread_pool:
                for file_name in list_of_files:
                    time.sleep(1)
                    thread_pool.submit(self.start_server, self.dest_ip, self.transmit_port, file_name,
                                       self.source_directory)

    def send_sock_msg(self, stock, connection):
        writer = connection.makefile('wb')
        data = pickle.dumps(stock)
        header = len(data).to_bytes(4, 'big')
        writer.write(header)
        writer.write(data)
        writer.flush()

    def recv_sock_msg(self, connection):
        try:
            reader = connection.makefile("rb")
            header = reader.read(4)
            length = int.from_bytes(header, "big")
            message = pickle.loads(reader.read(length))
            logger.info(f"Data received from socket: {message}")
            return message
        except Exception as e:
            logger.error(f"Error receiving socket message: {e}")
            return None

    def list_of_files_in_directory(self, directory):
        return [os.path.join(directory, f) for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

    def send_files_in_sub_folder(self, folder):
        list_of_files = self.list_of_files_in_directory(folder)
        logger.info(f"Directory {folder} with files: {list_of_files}")
        with ThreadPoolExecutor(max_workers=100) as sub_thread_pool:
            for file_name in list_of_files:
                time.sleep(1)
                sub_thread_pool.submit(self.start_server, self.dest_ip, self.transmit_port, file_name, folder)

    def read_file_in_chunks(self, filename, socketConnect):
        try:
            logger.info(f"Started reading file in chunks: {filename}")
            CHUNKSIZE = 1024 * 50
            with open(filename, 'rb') as file:
                while chunk := file.read(CHUNKSIZE):
                    socketConnect.sendall(chunk)
            logger.info(f"File transfer completed: {filename}")
            return 0
        except Exception as e:
            logger.error(f"Error during file read: {e}")
            return 1

    def start_server(self, host, port, file, target_dir):
        logger.info("In start server")
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
                client_socket.connect((host, port))
                logger.info(f"Connected to server {host}:{port}")
                file_info = [os.path.basename(file), os.path.getsize(file), target_dir]
                self.send_sock_msg(file_info, client_socket)
                self.read_file_in_chunks(file, client_socket)
                st_message = self.recv_sock_msg(client_socket)
                if st_message and st_message[0] == '322':
                    logger.info("Complete file transferred, deleting the source file " + str(file))
                    os.remove(file)
        except socket.error as e:
            logger.error(f"Connection failed {e}")
            time.sleep(1)
