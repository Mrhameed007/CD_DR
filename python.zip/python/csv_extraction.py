import pandas as pd

def get_column_data(df, column_name):
    """
    A generic function to get data from a specified column in the DataFrame.
    """
    return df[column_name].tolist()

# File path
file_path = r"D:\Users\Public\python\data.csv"

# Read the CSV file once
df = pd.read_csv(file_path)

# Fetch data from specific columns
S_Dir = get_column_data(df, 'source_dir')
T_Dir = get_column_data(df, 'target_dir')
T_IP = get_column_data(df, 'target_ip')

# Print the fetched data
for k in T_IP:
    print("Target_IP: " + str(k)) 

for i in S_Dir:
    print("Source Directories: " + str(i)) 

for j in T_Dir: 
    print("Target Directories: " + str(j)) 
