#client.py
import socket
import os
import pickle
import logging
import threading
import logging.handlers as handlers
from concurrent.futures import ThreadPoolExecutor

# Set up logging
logger = logging.getLogger('Logging')
logger.setLevel(logging.INFO)
log_filename = r'D:\Users\Public\python\Logging\Receiver_LOG.log'
formatter = logging.Formatter(
    "[%(asctime)-5s:%(levelname)-8s:%(filename)-20s:%(lineno)-5s - %(funcName)-30s](%(threadName)-25s %(message)s")
logHandler = handlers.TimedRotatingFileHandler(log_filename, when='midnight', interval=1, backupCount=0)
logHandler.setLevel(logging.INFO)
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)


def write_file_in_chunks(sockConnect, filename, filesize):
    CHUNKSIZE = 1024 * 50
    return_value = 1
    if filesize <= 0:
        logger.warning(f"Zero byte or invalid file size for transfer: {filename}")
        return return_value

    try:
        logger.info(f"Started writing the file in chunks: {filename} (Size: {filesize} bytes)")
        packet = b""
        while len(packet) < filesize:
            buffer = sockConnect.recv(min(CHUNKSIZE, filesize - len(packet)))
            if not buffer:
                break
            packet += buffer

        if len(packet) == filesize:
            with open(filename, 'wb') as file:
                file.write(packet)
            return_value = 0
            logger.info(f"File transfer completed: {filename}")
        else:
            logger.error(f"Incomplete file transfer for {filename}. Expected: {filesize}, Received: {len(packet)}")
    except Exception as e:
        logger.error(f"Error while writing file chunks: {e}")
    return return_value


def send_sock_msg(stock, connection):
    writer = connection.makefile('wb')
    data = pickle.dumps(stock)
    header = len(data).to_bytes(4, 'big')
    writer.write(header)
    writer.write(data)
    writer.flush()


def recv_sock_msg(connection):
    try:
        reader = connection.makefile("rb")
        header = reader.read(4)
        length = int.from_bytes(header, "big")
        message = pickle.loads(reader.read(length))
        logger.info(f"Data received from socket: {message}")
        return message
    except Exception as e:
        logger.error(f"Error receiving socket message: {e}")
        return None


def call_receive_data(received_data, connection):
    if received_data:
        output_file = os.path.join(received_data[2], received_data[0])
        logger.info(f"Receiving file: {output_file}")
        rtn_value = write_file_in_chunks(connection, output_file, received_data[1])
        if rtn_value == 0:
            send_sock_msg(["322"], connection)

    else:
        logger.warning("No data received from client.")


def receive_files(host, port):
    thread_pool = ThreadPoolExecutor(max_workers=100)  # Increased thread pool size
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            server_socket.bind((host, port))
            server_socket.listen(20)
            logger.info(f"Server listening on {host}:{port}")
            while True:
                conn, addr = server_socket.accept()
                logger.info(f"Connection established with {addr}")
                data = recv_sock_msg(conn)
                thread_pool.submit(call_receive_data, data, conn)
    except Exception as e:
        logger.error(f"Error setting up the server socket: {e}")


# def get_ip_address():
#     hostname = socket.gethostname()
#     ip_address = socket.gethostbyname(hostname)
#     return ip_address
#
#
# ip = get_ip_address()
ip="192.168.1.16"

logger.info(f"Server Started--------------: {ip}")

host = ip
port = 1374
receive_files(host, port)